#pragma once
#include "Item.h"
#include <Attributes/ThrowableAttributes.h>

class CThrowable : public CItem
{
	CThrowable(int index, CThrowableAttributes attribute);
	~CThrowable();

public:

	CThrowableAttributes::ThrowableItemType GetType() { return m_attribute.type; };

	int GetSheetForGroup();
	int GetOffsetForGroup();
	ItemGroup GetGroup();

	CString GetName();

private:
	CThrowableAttributes m_attribute;
};

