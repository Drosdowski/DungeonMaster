#include "stdafx.h"
#include "WallDecoration.h"
