#include "stdafx.h"
#include "MagicMissile.h"
