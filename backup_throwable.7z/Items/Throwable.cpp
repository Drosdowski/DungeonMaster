#include "stdafx.h"
#include "Throwable.h"
#include <cassert>

CThrowable::CThrowable(int index, CThrowableAttributes attribute) : CItem(index, ThrowableItem) {
	m_attribute = attribute;
}

CThrowable::~CThrowable() {
}

int CThrowable::GetSheetForGroup() {
	if (m_attribute.type < 8)
		return 0;
	else if (m_attribute.type < 38 || m_attribute.type == 44)
		return 1;
	else
		assert(false); // todo !!
	return -1;
}

CItem::ItemGroup CThrowable::GetGroup() {
	return ItemGroup::Throwable;
}

int CThrowable::GetOffsetForGroup() {
	return 1;
}

CString CThrowable::GetName() {
	switch (m_attribute.type) {
		case CThrowableAttributes::Rock: return "Rock";
		case CThrowableAttributes::PoisonDart: return "Poison Dart";
		case CThrowableAttributes::ThrowingStar: return "Throwing Star";
		case CThrowableAttributes::Potion: return "Potion";
		case CThrowableAttributes::Bomb: return "Bomb";
	}
	assert(false);
	return "UNKNOWN";
}