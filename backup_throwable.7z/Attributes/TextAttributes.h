#pragma once
class CTextAttributes
{
public:
	CString text;
	int visible;
	int text_data;
};

