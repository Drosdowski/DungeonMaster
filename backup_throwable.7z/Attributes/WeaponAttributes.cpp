#include "stdafx.h"
#include "WeaponAttributes.h"
