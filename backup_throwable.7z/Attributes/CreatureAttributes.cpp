#include "stdafx.h"
#include "CreatureAttributes.h"
