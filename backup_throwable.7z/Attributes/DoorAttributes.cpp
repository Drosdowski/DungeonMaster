#include "stdafx.h"
#include "DoorAttributes.h"

