#pragma once
class CScrollAttributes
{
public:
	const char* text;
	bool open;
};

