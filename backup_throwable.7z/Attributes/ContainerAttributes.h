#pragma once

class CContainerAttributes
{
public:
	bool open;

};

