#include "stdafx.h"
#include "ClothAttributes.h"
