#pragma once
class CThrowableAttributes
{
public:
	enum ThrowableItemType {
		Rock = 30,
		PoisonDart = 31,
		ThrowingStar = 32,
		Potion = 68,
		Bomb = 69
	};
	ThrowableItemType type;
};

